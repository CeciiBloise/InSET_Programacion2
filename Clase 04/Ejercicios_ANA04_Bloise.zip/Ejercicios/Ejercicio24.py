"""Ejercicio 24"""
"""Tomar el diccionario del ejercicio 19. Imprimir su longitud"""

d = {'a': 'Lunes', 'b': 'Martes', 'c': 'Miércoles', 'd': 'Jueves', 'e': 'Viernes', 'f': 'Sábado', 'g': 'Domingo'}

print(len(d))