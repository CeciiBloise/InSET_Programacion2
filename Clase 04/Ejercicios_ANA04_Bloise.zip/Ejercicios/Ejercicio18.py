"""Ejercicio 18"""
"""Crear una lista l1 con todos los días de la semana. Recorrer l1
imprimiendo elemento por elemento"""

l1 = ['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo']

# Recorrer e imprimir cada elemento
for dia in l1:
    print(dia)
