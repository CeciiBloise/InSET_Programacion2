"""Ejercicio 13"""
"""Crear una tupla t1 con todos los días de la semana. Mostrar por pantalla
el número de elemento correspondiente al miércoles."""

t1=("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")

print(t1.index("Miercoles"))#index para mostrar por pantalla el número de elemento correspondiente al miércoles


