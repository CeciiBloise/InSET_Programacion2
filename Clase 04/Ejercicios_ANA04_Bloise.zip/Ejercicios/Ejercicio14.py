"""Ejercicio 14"""
"""Crear una tupla t1 con todos los días de la semana. Averiguar si domingo
se encuentra entre todos los días de la semana."""

t1=("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")

if "domingo" in t1:
    print("Si, domingo se encuentra en la tupla.")
else:
    print("No, domingo no se encuentra en la tupla.")

