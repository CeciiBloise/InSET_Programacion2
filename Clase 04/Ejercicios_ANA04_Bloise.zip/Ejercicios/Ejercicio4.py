"""Ejercicio 4"""
"""Ingresar por teclado dos enteros y almacenarlos en a y b. Crear una
función de dos parámetros que devuelve la suma de esos parámetros
Usar la función creada para calcular la suma de a y b. Mostrar por pantalla
el resultado de la suma"""

print("Ingrese dos numeros\n")
a=input("Ingrese el primer numero: ")
b=input("Ingrese el segundo numero: ")

a=int(a)
b=int(b)

def suma():
    suma=print("La suma es: ", a+b)
    

suma()
    



