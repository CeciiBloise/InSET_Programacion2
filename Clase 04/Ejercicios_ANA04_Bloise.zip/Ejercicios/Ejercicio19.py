"""Ejercicio 19"""
"""Crear un diccionario d con todos los días de la semana poniendo como
clave las siete primeras letras del alfabeto. Imprimir el diccionario."""

#Diccionario 
d = {'a': 'Lunes', 'b': 'Martes', 'c': 'Miércoles', 'd': 'Jueves', 'e': 'Viernes', 'f': 'Sábado', 'g': 'Domingo'}

print(d)
