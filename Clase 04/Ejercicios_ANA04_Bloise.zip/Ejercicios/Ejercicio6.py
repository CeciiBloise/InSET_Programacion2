"""Ejercicio 6"""
"""Crear una lista con los días de la semana. Mostrar el contenido de la lista
con un único print. Mostrar el contenido de la lista elemento por elemento."""

lista_dias_de_la_semana=['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes', 'Sabado', 'Domingo']

dias= ' '.join(lista_dias_de_la_semana)

print(dias)