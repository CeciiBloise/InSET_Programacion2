"""Ejercicio 7"""
"""Crear una lista con los días hábiles de la semana. Agregar a la lista el
sábado y el domingo. Mostrar el contenido de la lista con un único print."""


lista_dias_habiles=['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes']

"""Utilizo append() para agregar un dia al final de la lista"""
lista_dias_habiles.append('Sabado')
lista_dias_habiles.append('Domingo')

print(lista_dias_habiles)

