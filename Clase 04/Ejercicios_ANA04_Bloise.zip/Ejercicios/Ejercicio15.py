"""Ejercicio 15"""
"""Crear una tupla t1 con todos los días de la semana. Imprimir la longitud
de t1"""

t1=("Lunes", "Martes", "Miercoles", "Jueves", "Viernes", "Sabado", "Domingo")

print("Longitud de la tupla:", len(t1))