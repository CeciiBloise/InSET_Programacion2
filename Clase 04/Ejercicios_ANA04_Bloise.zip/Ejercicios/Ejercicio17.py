"""Ejercicio 17"""
"""Crear una lista l1 con todos los días de la semana. Crear una tupla t1 a
partir de l1."""

l1 = ['Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo']

t1 = tuple(l1)

print(t1)

