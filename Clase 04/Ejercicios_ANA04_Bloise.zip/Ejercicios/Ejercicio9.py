"""Ejercicio 9"""
"""Crear una lista con los días hábiles de la semana y otra lista con el sábado
y el domingo. Extender la primera lista con la segunda. Mostrar el
contenido de la lista con un único print."""

lista_dias_habiles=['Lunes', 'Martes', 'Miercoles', 'Jueves', 'Viernes']
lista_fin_de_semana=['Sabado', 'Domingo']

lista_semana_completa=lista_dias_habiles+lista_fin_de_semana

print(lista_semana_completa)