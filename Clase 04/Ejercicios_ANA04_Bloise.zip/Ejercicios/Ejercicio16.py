"""Ejercicio 16"""
"""Crear una tupla t1 con todos los días de la semana.
Crear una lista l1 a partir de t1"""


t1 = ('Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado', 'Domingo')

# Crear la lista l1 a partir de t1
l1 = list(t1)

print(l1)
