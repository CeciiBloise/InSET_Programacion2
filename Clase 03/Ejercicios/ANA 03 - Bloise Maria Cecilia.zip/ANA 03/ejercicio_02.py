#EJERCICIO 02
"""
Pidan el ingreso de un dato por teclado y guárdenlo en una variable a. Convierta el
dato a en un entero usando la función int Muestren por pantalla el contenido de a.
"""

a=input("ingrese un dato:\n")

a=int(a) #convierto a entero

print("\nEl dato ingresado es", a)