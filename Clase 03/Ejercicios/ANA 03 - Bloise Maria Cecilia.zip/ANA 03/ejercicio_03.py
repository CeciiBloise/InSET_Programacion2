#EJERCICIO 03
"""
Pidan el ingreso de dos datos a y b por teclado. Convierta a y b a enteros usando la
función int. Muestren por pantalla el contenido de a+b
"""

print("Ingre los datos:\n")

a=input("\nIngrese un dato para a: ")

b=input("\nIngrese un dato para b: ")

#Convierto a entero

a=int(a)
b=int(b)

print("\nla suma es ", a+b)