#EJERCICIO 01
"""
Pidan el ingreso de un dato por teclado y guárdenlo en una variable a.
Muestren por pantalla el contenido de a.
"""
a=input("ingrese un dato: ")

print("\nEl dato ingresado es", a)